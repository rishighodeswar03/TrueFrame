# TrueFrame: Social Media Platform for Blocking Deepfake Video Uploads

TrueFrame is a cutting-edge social media platform that uses advanced AI technology to detect and block deepfake videos, ensuring that only authentic content is shared on the platform.

## 🚀 Features

- **AI-Powered Deepfake Detection**: Advanced machine learning algorithms analyze uploaded videos in real-time
- **Real-time Video Analysis**: Videos are processed during upload to ensure authenticity
- **User Authentication**: Secure login and registration system
- **Social Features**: Like, comment, and share authentic videos
- **Modern UI**: Beautiful, responsive design with dark/light themes
- **Statistics Dashboard**: Track platform usage and deepfake detection rates
- **Video Thumbnails**: Automatic thumbnail generation for uploaded videos

## 🛠️ Technology Stack

### Backend
- **Python 3.8+**
- **Flask**: Web framework
- **TensorFlow**: Deep learning framework for deepfake detection
- **OpenCV**: Computer vision library for video processing
- **SQLAlchemy**: Database ORM
- **JWT**: Authentication tokens
- **Flask-Migrate**: Database migrations

### Frontend
- **HTML5/CSS3**: Modern web standards
- **JavaScript (ES6+)**: Interactive functionality
- **Font Awesome**: Icons
- **Google Fonts**: Typography

### Database
- **SQLite**: Default database (easily configurable for PostgreSQL/MySQL)

## 📋 Prerequisites

- Python 3.8 or higher
- pip (Python package installer)
- Modern web browser

## 🚀 Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/trueframe.git
   cd trueframe
   ```

2. **Create a virtual environment**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**
   ```bash
   # Create a .env file
   echo "SECRET_KEY=your-secret-key-here" > .env
   echo "JWT_SECRET_KEY=your-jwt-secret-here" >> .env
   echo "DATABASE_URL=sqlite:///trueframe.db" >> .env
   ```

5. **Initialize the database**
   ```bash
   python app.py
   ```

6. **Run the application**
   ```bash
   python app.py
   ```

The application will be available at `http://localhost:5000`

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `SECRET_KEY` | Flask secret key for sessions | `your-secret-key-here` |
| `JWT_SECRET_KEY` | JWT token signing key | `jwt-secret-string` |
| `DATABASE_URL` | Database connection string | `sqlite:///trueframe.db` |
| `UPLOAD_FOLDER` | Directory for uploaded files | `uploads` |
| `MAX_CONTENT_LENGTH` | Maximum file size (bytes) | `104857600` (100MB) |

### Database Configuration

The application supports multiple database backends:

- **SQLite** (default): `sqlite:///trueframe.db`
- **PostgreSQL**: `postgresql://user:password@localhost/trueframe`
- **MySQL**: `mysql://user:password@localhost/trueframe`

## 📁 Project Structure

```
trueframe/
├── app.py                 # Main Flask application
├── models.py             # Database models
├── deepfake_detector.py  # Deepfake detection logic
├── requirements.txt      # Python dependencies
├── README.md            # Project documentation
├── LICENSE              # License file
├── static/              # Static web assets
│   ├── css/
│   │   └── style.css    # Main stylesheet
│   ├── js/
│   │   └── app.js       # Frontend JavaScript
│   └── index.html       # Main HTML template
└── uploads/             # Uploaded files
    ├── videos/          # Video files
    └── thumbnails/      # Generated thumbnails
```

## 🔍 How It Works

### Deepfake Detection Process

1. **Video Upload**: User uploads a video file
2. **Format Validation**: Check file type and size
3. **Frame Extraction**: Extract key frames from the video
4. **Face Detection**: Identify faces in each frame using OpenCV
5. **AI Analysis**: Process faces through deepfake detection model
6. **Confidence Scoring**: Calculate confidence scores for each frame
7. **Decision Making**: Determine if video is authentic or deepfake
8. **Result**: Accept authentic videos, reject deepfakes

### Detection Methods

- **CNN-based Analysis**: Convolutional Neural Network trained on authentic vs. deepfake data
- **Face Landmark Analysis**: Examination of facial features and movements
- **Temporal Consistency**: Analysis across multiple frames
- **Statistical Analysis**: Confidence scoring and threshold comparison

## 🔐 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: Bcrypt password encryption
- **File Validation**: Strict file type and size validation
- **SQL Injection Protection**: SQLAlchemy ORM prevents SQL injection
- **CORS Configuration**: Cross-origin resource sharing protection

## 📊 API Endpoints

### Authentication
- `POST /api/register` - User registration
- `POST /api/login` - User login

### Videos
- `POST /api/upload` - Upload video (requires authentication)
- `GET /api/videos` - Get list of videos
- `POST /api/videos/<id>/like` - Like/unlike video
- `GET /api/videos/<id>/comments` - Get video comments
- `POST /api/videos/<id>/comments` - Add comment

### Statistics
- `GET /api/stats` - Get platform statistics

## 🧪 Testing

Run the application and test the following features:

1. **User Registration/Login**
2. **Video Upload** (try with both authentic and test videos)
3. **Deepfake Detection** (upload videos to test detection)
4. **Social Features** (like, comment on videos)
5. **Statistics Dashboard**

## 🚀 Deployment

### Production Deployment

1. **Set up a production database** (PostgreSQL recommended)
2. **Configure environment variables**
3. **Use a production WSGI server**:
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:8000 app:app
   ```
4. **Set up reverse proxy** (Nginx recommended)
5. **Configure SSL certificates**

### Docker Deployment

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- TensorFlow team for the machine learning framework
- OpenCV community for computer vision tools
- Flask team for the web framework
- All contributors and testers

## 📞 Support

For support, email support@trueframe.com or join our Discord server.

## 🔮 Roadmap

- [ ] Real-time video streaming
- [ ] Mobile app development
- [ ] Advanced deepfake detection models
- [ ] Video compression and optimization
- [ ] Multi-language support
- [ ] API rate limiting
- [ ] Video moderation tools
- [ ] Analytics dashboard

---

**TrueFrame** - Protecting digital authenticity, one video at a time.
