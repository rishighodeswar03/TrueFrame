from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
import cv2
import numpy as np
import tensorflow as tf
from datetime import datetime, timedelta
import uuid
import json
from deepfake_detector import DeepfakeDetector
from models import db, User, Video, Comment, Like
import logging

# Suppress TensorFlow warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
tf.get_logger().setLevel('ERROR')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-secret-key-here')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///trueframe.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'jwt-secret-string')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max file size

# Initialize extensions
CORS(app)
db.init_app(app)
jwt = JWTManager(app)
migrate = Migrate(app, db)
deepfake_detector = DeepfakeDetector()

# Create upload directory
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'videos'), exist_ok=True)
os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'thumbnails'), exist_ok=True)

# Allowed file extensions
ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov', 'mkv', 'webm'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

@app.route('/uploads/videos/<filename>')
def serve_video(filename):
    """Serve uploaded video files."""
    try:
        return send_from_directory(os.path.join(app.config['UPLOAD_FOLDER'], 'videos'), filename)
    except FileNotFoundError:
        return jsonify({'error': 'Video not found'}), 404

@app.route('/uploads/thumbnails/<filename>')
def serve_thumbnail(filename):
    """Serve video thumbnail files."""
    try:
        return send_from_directory(os.path.join(app.config['UPLOAD_FOLDER'], 'thumbnails'), filename)
    except FileNotFoundError:
        return jsonify({'error': 'Thumbnail not found'}), 404

# Authentication endpoints
@app.route('/api/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        
        if not username or not email or not password:
            return jsonify({'error': 'Missing required fields'}), 400
        
        if User.query.filter_by(username=username).first():
            return jsonify({'error': 'Username already exists'}), 400
        
        if User.query.filter_by(email=email).first():
            return jsonify({'error': 'Email already exists'}), 400
        
        hashed_password = generate_password_hash(password)
        user = User(username=username, email=email, password_hash=hashed_password)
        db.session.add(user)
        db.session.commit()
        
        access_token = create_access_token(identity=user.id)
        return jsonify({
            'message': 'User created successfully',
            'access_token': access_token,
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email
            }
        }), 201
        
    except Exception as e:
        logger.error(f"Registration error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': 'Missing credentials'}), 400
        
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            access_token = create_access_token(identity=user.id)
            return jsonify({
                'access_token': access_token,
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email
                }
            }), 200
        
        return jsonify({'error': 'Invalid credentials'}), 401
        
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

# Video upload and processing
@app.route('/api/upload', methods=['POST'])
@jwt_required()
def upload_video():
    try:
        if 'video' not in request.files:
            return jsonify({'error': 'No video file provided'}), 400
        
        file = request.files['video']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type. Only MP4, AVI, MOV, MKV, WEBM are allowed.'}), 400
        
        # Generate unique filename
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4()}_{filename}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'videos', unique_filename)
        file.save(file_path)
        
        # Get user ID
        user_id = get_jwt_identity()
        
        # Analyze video for deepfake detection
        logger.info(f"Analyzing video: {unique_filename}")
        try:
            is_deepfake, confidence, analysis_data = deepfake_detector.analyze_video(file_path)
        except Exception as e:
            logger.error(f"Video analysis failed: {str(e)}")
            # If analysis fails, reject the upload for safety
            os.remove(file_path)
            return jsonify({
                'error': 'Video analysis failed. Please try again.',
                'details': 'Analysis error occurred'
            }), 500
        
        # Create video record
        video = Video(
            filename=unique_filename,
            original_filename=filename,
            user_id=user_id,
            is_deepfake=is_deepfake,
            confidence_score=confidence,
            analysis_data=json.dumps(analysis_data),
            file_path=file_path
        )
        
        # If it's a deepfake, reject the upload
        if is_deepfake:
            os.remove(file_path)  # Remove the uploaded file
            return jsonify({
                'error': 'Video rejected: Deepfake detected',
                'confidence': confidence,
                'details': analysis_data
            }), 403
        
        # Generate thumbnail
        thumbnail_path = deepfake_detector.generate_thumbnail(file_path, unique_filename)
        video.thumbnail_path = thumbnail_path
        
        db.session.add(video)
        db.session.commit()
        
        return jsonify({
            'message': 'Video uploaded successfully',
            'video_id': video.id,
            'confidence': confidence,
            'thumbnail': thumbnail_path
        }), 201
        
    except Exception as e:
        logger.error(f"Upload error: {str(e)}")
        return jsonify({'error': 'Upload failed'}), 500

@app.route('/api/videos', methods=['GET'])
def get_videos():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        
        videos = Video.query.filter_by(is_deepfake=False).order_by(Video.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        result = []
        for video in videos.items:
            user = User.query.get(video.user_id)
            result.append({
                'id': video.id,
                'filename': video.original_filename,
                'thumbnail': video.thumbnail_path,
                'uploaded_by': user.username if user else 'Unknown',
                'created_at': video.created_at.isoformat(),
                'likes_count': video.likes.count(),
                'comments_count': video.comments.count()
            })
        
        return jsonify({
            'videos': result,
            'total': videos.total,
            'pages': videos.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        logger.error(f"Get videos error: {str(e)}")
        return jsonify({'error': 'Failed to fetch videos'}), 500

@app.route('/api/videos/<int:video_id>/like', methods=['POST'])
@jwt_required()
def like_video(video_id):
    try:
        user_id = get_jwt_identity()
        
        # Check if already liked
        existing_like = Like.query.filter_by(user_id=user_id, video_id=video_id).first()
        if existing_like:
            db.session.delete(existing_like)
            db.session.commit()
            return jsonify({'message': 'Like removed', 'liked': False}), 200
        
        # Add new like
        like = Like(user_id=user_id, video_id=video_id)
        db.session.add(like)
        db.session.commit()
        
        return jsonify({'message': 'Video liked', 'liked': True}), 201
        
    except Exception as e:
        logger.error(f"Like error: {str(e)}")
        return jsonify({'error': 'Failed to like video'}), 500

@app.route('/api/videos/<int:video_id>/comments', methods=['GET', 'POST'])
@jwt_required()
def video_comments(video_id):
    try:
        if request.method == 'GET':
            comments = Comment.query.filter_by(video_id=video_id).order_by(Comment.created_at.desc()).all()
            result = []
            for comment in comments:
                user = User.query.get(comment.user_id)
                result.append({
                    'id': comment.id,
                    'content': comment.content,
                    'user': user.username if user else 'Unknown',
                    'created_at': comment.created_at.isoformat()
                })
            return jsonify({'comments': result}), 200
        
        elif request.method == 'POST':
            data = request.get_json()
            content = data.get('content')
            if not content:
                return jsonify({'error': 'Comment content required'}), 400
            
            user_id = get_jwt_identity()
            comment = Comment(user_id=user_id, video_id=video_id, content=content)
            db.session.add(comment)
            db.session.commit()
            
            return jsonify({
                'message': 'Comment added',
                'comment_id': comment.id
            }), 201
            
    except Exception as e:
        logger.error(f"Comments error: {str(e)}")
        return jsonify({'error': 'Failed to process comments'}), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    try:
        total_videos = Video.query.count()
        deepfake_videos = Video.query.filter_by(is_deepfake=True).count()
        legitimate_videos = total_videos - deepfake_videos
        total_users = User.query.count()
        
        return jsonify({
            'total_videos': total_videos,
            'legitimate_videos': legitimate_videos,
            'deepfake_videos': deepfake_videos,
            'total_users': total_users,
            'deepfake_percentage': (deepfake_videos / total_videos * 100) if total_videos > 0 else 0
        }), 200
        
    except Exception as e:
        logger.error(f"Stats error: {str(e)}")
        return jsonify({'error': 'Failed to fetch stats'}), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000)
