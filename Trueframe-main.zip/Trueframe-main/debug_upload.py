#!/usr/bin/env python3
"""
Debug script to test video upload functionality
"""

import requests
import json
import os

def test_upload():
    """Test video upload with debugging."""
    
    # First, register a user
    register_data = {
        "username": "debuguser",
        "email": "debug@test.com",
        "password": "debugpass123"
    }
    
    try:
        # Try to register
        response = requests.post("http://localhost:5000/api/register", json=register_data)
        print(f"📝 Registration response: {response.status_code}")
        if response.status_code not in [200, 201]:
            print(f"Registration response: {response.text}")
        
        # Then login
        login_data = {
            "username": "debuguser",
            "password": "debugpass123"
        }
        
        response = requests.post("http://localhost:5000/api/login", json=login_data)
        if response.status_code != 200:
            print(f"Login failed: {response.status_code}")
            print(f"Response: {response.text}")
            return
        
        token = response.json().get('access_token')
        if not token:
            print("No token received")
            return
        
        print(f"✅ Login successful, token: {token[:20]}...")
        
        # Test video upload with a simple request
        headers = {
            'Authorization': f'Bearer {token}'
        }
        
        # Create a simple test file (not a real video, just to test the endpoint)
        test_file = "test_video.mp4"
        with open(test_file, 'wb') as f:
            # Write some dummy data
            f.write(b'fake video content for testing')
        
        try:
            with open(test_file, 'rb') as f:
                files = {'video': (test_file, f, 'video/mp4')}
                
                print("📤 Attempting video upload...")
                response = requests.post(
                    "http://localhost:5000/api/upload",
                    headers=headers,
                    files=files
                )
                
                print(f"📊 Upload response: {response.status_code}")
                print(f"📄 Response text: {response.text}")
                
                if response.status_code == 422:
                    print("❌ 422 Unprocessable Entity - Check server logs for details")
                elif response.status_code == 201:
                    print("✅ Upload successful!")
                elif response.status_code == 403:
                    print("🛡️ Video rejected as deepfake")
                elif response.status_code == 500:
                    print("💥 Server error during analysis")
                else:
                    print(f"⚠️ Unexpected status code: {response.status_code}")
                    
        except Exception as e:
            print(f"❌ Upload error: {e}")
        finally:
            # Clean up test file
            if os.path.exists(test_file):
                os.remove(test_file)
                
    except Exception as e:
        print(f"❌ Test failed: {e}")

if __name__ == '__main__':
    test_upload()