import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense, Dropout
import os
import logging
from PIL import Image
import json
from datetime import datetime

# Suppress TensorFlow warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
tf.get_logger().setLevel('ERROR')

logger = logging.getLogger(__name__)

class DeepfakeDetector:
    def __init__(self):
        """Initialize the advanced deepfake detection system."""
        self.model = None
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        # Try to import optional dependencies
        self.dlib_available = False
        self.mediapipe_available = False
        self.face_detector = None
        self.landmark_predictor = None
        self.face_mesh = None
        
        # Try to load dlib
        try:
            import dlib
            self.face_detector = dlib.get_frontal_face_detector()
            self.dlib_available = True
            
            # Try to load landmark predictor
            predictor_path = os.path.join(os.path.dirname(__file__), 'shape_predictor_68_face_landmarks.dat')
            if os.path.exists(predictor_path):
                self.landmark_predictor = dlib.shape_predictor(predictor_path)
                logger.info("Dlib landmark predictor loaded successfully")
            else:
                logger.info("Dlib available but landmark predictor not found")
        except ImportError:
            logger.info("Dlib not available, using OpenCV only")
        except Exception as e:
            logger.warning(f"Could not load dlib: {e}")
        
        # Try to load MediaPipe
        try:
            import mediapipe as mp
            self.mp_face_mesh = mp.solutions.face_mesh
            self.mp_drawing = mp.solutions.drawing_utils
            self.face_mesh = self.mp_face_mesh.FaceMesh(
                static_image_mode=False,
                max_num_faces=1,
                refine_landmarks=True,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5
            )
            self.mediapipe_available = True
            logger.info("MediaPipe loaded successfully")
        except ImportError:
            logger.info("MediaPipe not available, using OpenCV and Dlib only")
        except Exception as e:
            logger.warning(f"Could not load MediaPipe: {e}")
        
        self.load_model()
    
    def load_model(self):
        """Load the advanced deepfake detection model."""
        try:
            self.model = self.create_advanced_model()
            logger.info("Advanced deepfake detection model loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load model: {str(e)}")
            self.model = self.create_advanced_model()
    
    def create_advanced_model(self):
        """Create an advanced CNN model for deepfake detection."""
        # Create a custom CNN model optimized for deepfake detection
        model = tf.keras.Sequential([
            # Input layer
            tf.keras.layers.Input(shape=(224, 224, 3)),
            
            # First convolutional block
            tf.keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
            tf.keras.layers.BatchNormalization(),
            tf.keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
            tf.keras.layers.MaxPooling2D((2, 2)),
            tf.keras.layers.Dropout(0.25),
            
            # Second convolutional block
            tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
            tf.keras.layers.BatchNormalization(),
            tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
            tf.keras.layers.MaxPooling2D((2, 2)),
            tf.keras.layers.Dropout(0.25),
            
            # Third convolutional block
            tf.keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
            tf.keras.layers.BatchNormalization(),
            tf.keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
            tf.keras.layers.MaxPooling2D((2, 2)),
            tf.keras.layers.Dropout(0.25),
            
            # Fourth convolutional block
            tf.keras.layers.Conv2D(256, (3, 3), activation='relu', padding='same'),
            tf.keras.layers.BatchNormalization(),
            tf.keras.layers.Conv2D(256, (3, 3), activation='relu', padding='same'),
            tf.keras.layers.MaxPooling2D((2, 2)),
            tf.keras.layers.Dropout(0.25),
            
            # Global average pooling
            tf.keras.layers.GlobalAveragePooling2D(),
            
            # Dense layers
            tf.keras.layers.Dense(512, activation='relu'),
            tf.keras.layers.BatchNormalization(),
            tf.keras.layers.Dropout(0.5),
            tf.keras.layers.Dense(256, activation='relu'),
            tf.keras.layers.BatchNormalization(),
            tf.keras.layers.Dropout(0.5),
            tf.keras.layers.Dense(128, activation='relu'),
            tf.keras.layers.Dropout(0.3),
            tf.keras.layers.Dense(1, activation='sigmoid')
        ])
        
        model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
            loss='binary_crossentropy',
            metrics=['accuracy', 'precision', 'recall']
        )
        
        return model
    
    def extract_faces(self, frame):
        """Extract faces from a video frame using available detection methods."""
        face_images = []
        
        # Method 1: OpenCV Haar Cascade (always available)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces_cv = self.face_cascade.detectMultiScale(gray, 1.1, 4)
        
        for (x, y, w, h) in faces_cv:
            face = frame[y:y+h, x:x+w]
            if face.size > 0:
                face_resized = cv2.resize(face, (224, 224))
                face_images.append(face_resized)
        
        # Method 2: Dlib face detection (if available)
        if self.dlib_available and self.face_detector:
            try:
                faces_dlib = self.face_detector(gray)
                for face in faces_dlib:
                    x, y, w, h = face.left(), face.top(), face.width(), face.height()
                    face_img = frame[y:y+h, x:x+w]
                    if face_img.size > 0:
                        face_resized = cv2.resize(face_img, (224, 224))
                        face_images.append(face_resized)
            except Exception as e:
                logger.debug(f"Dlib face detection failed: {e}")
        
        # Method 3: MediaPipe face detection (if available)
        if self.mediapipe_available and self.face_mesh:
            try:
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = self.face_mesh.process(rgb_frame)
                
                if results.multi_face_landmarks:
                    for face_landmarks in results.multi_face_landmarks:
                        # Get face bounding box from landmarks
                        landmarks = np.array([[lm.x * frame.shape[1], lm.y * frame.shape[0]] for lm in face_landmarks.landmark])
                        x_min, y_min = int(landmarks[:, 0].min()), int(landmarks[:, 1].min())
                        x_max, y_max = int(landmarks[:, 0].max()), int(landmarks[:, 1].max())
                        
                        # Add padding
                        padding = 20
                        x_min = max(0, x_min - padding)
                        y_min = max(0, y_min - padding)
                        x_max = min(frame.shape[1], x_max + padding)
                        y_max = min(frame.shape[0], y_max + padding)
                        
                        face_img = frame[y_min:y_max, x_min:x_max]
                        if face_img.size > 0:
                            face_resized = cv2.resize(face_img, (224, 224))
                            face_images.append(face_resized)
            except Exception as e:
                logger.debug(f"MediaPipe face detection failed: {e}")
        
        return face_images
    
    def analyze_face_landmarks(self, face_img):
        """Analyze facial landmarks for deepfake indicators."""
        try:
            if not self.dlib_available or not self.face_detector or not self.landmark_predictor:
                return {"landmark_analysis": "Dlib not available - using basic analysis"}
            
            gray = cv2.cvtColor(face_img, cv2.COLOR_BGR2GRAY)
            faces = self.face_detector(gray)
            
            if not faces:
                return {"landmark_analysis": "No faces detected"}
            
            landmarks = []
            for face in faces:
                if self.landmark_predictor:
                    shape = self.landmark_predictor(gray, face)
                    landmarks = np.array([[p.x, p.y] for p in shape.parts()])
                    break
            
            if len(landmarks) == 0:
                return {"landmark_analysis": "No landmarks detected"}
            
            # Analyze facial symmetry
            symmetry_score = self.calculate_facial_symmetry(landmarks)
            
            # Analyze eye aspect ratio
            eye_aspect_ratio = self.calculate_eye_aspect_ratio(landmarks)
            
            # Analyze mouth aspect ratio
            mouth_aspect_ratio = self.calculate_mouth_aspect_ratio(landmarks)
            
            return {
                "landmark_analysis": "Successful",
                "facial_symmetry": symmetry_score,
                "eye_aspect_ratio": eye_aspect_ratio,
                "mouth_aspect_ratio": mouth_aspect_ratio,
                "landmark_count": len(landmarks)
            }
            
        except Exception as e:
            return {"landmark_analysis": f"Error: {str(e)}"}
    
    def calculate_facial_symmetry(self, landmarks):
        """Calculate facial symmetry score."""
        try:
            # Get key facial points
            left_eye = np.mean(landmarks[36:42], axis=0)  # Left eye center
            right_eye = np.mean(landmarks[42:48], axis=0)  # Right eye center
            nose_tip = landmarks[30]  # Nose tip
            mouth_center = np.mean(landmarks[48:68], axis=0)  # Mouth center
            
            # Calculate symmetry based on distances
            left_dist = np.linalg.norm(left_eye - nose_tip)
            right_dist = np.linalg.norm(right_eye - nose_tip)
            
            symmetry_ratio = min(left_dist, right_dist) / max(left_dist, right_dist)
            return float(symmetry_ratio)
            
        except Exception as e:
            return 0.5  # Default neutral score
    
    def calculate_eye_aspect_ratio(self, landmarks):
        """Calculate eye aspect ratio (EAR) for blink detection."""
        try:
            # Left eye EAR
            left_eye_vertical_1 = np.linalg.norm(landmarks[37] - landmarks[41])
            left_eye_vertical_2 = np.linalg.norm(landmarks[38] - landmarks[40])
            left_eye_horizontal = np.linalg.norm(landmarks[36] - landmarks[39])
            left_ear = (left_eye_vertical_1 + left_eye_vertical_2) / (2.0 * left_eye_horizontal)
            
            # Right eye EAR
            right_eye_vertical_1 = np.linalg.norm(landmarks[43] - landmarks[47])
            right_eye_vertical_2 = np.linalg.norm(landmarks[44] - landmarks[46])
            right_eye_horizontal = np.linalg.norm(landmarks[42] - landmarks[45])
            right_ear = (right_eye_vertical_1 + right_eye_vertical_2) / (2.0 * right_eye_horizontal)
            
            return float((left_ear + right_ear) / 2.0)
            
        except Exception as e:
            return 0.3  # Default EAR
    
    def calculate_mouth_aspect_ratio(self, landmarks):
        """Calculate mouth aspect ratio for mouth movement analysis."""
        try:
            mouth_vertical_1 = np.linalg.norm(landmarks[51] - landmarks[57])
            mouth_vertical_2 = np.linalg.norm(landmarks[52] - landmarks[56])
            mouth_vertical_3 = np.linalg.norm(landmarks[53] - landmarks[55])
            mouth_horizontal = np.linalg.norm(landmarks[48] - landmarks[54])
            
            mar = (mouth_vertical_1 + mouth_vertical_2 + mouth_vertical_3) / (3.0 * mouth_horizontal)
            return float(mar)
            
        except Exception as e:
            return 0.2  # Default MAR
    
    def detect_face_swapping_artifacts(self, face_img):
        """Detect common face swapping artifacts."""
        try:
            # Convert to grayscale for analysis
            gray = cv2.cvtColor(face_img, cv2.COLOR_BGR2GRAY)
            
            # Edge detection to find sharp boundaries
            edges = cv2.Canny(gray, 50, 150)
            edge_density = np.sum(edges > 0) / edges.size
            
            # Frequency domain analysis
            f_transform = np.fft.fft2(gray)
            f_shift = np.fft.fftshift(f_transform)
            magnitude_spectrum = np.log(np.abs(f_shift) + 1)
            
            # Calculate high-frequency content
            h, w = magnitude_spectrum.shape
            center_h, center_w = h // 2, w // 2
            high_freq_mask = np.ones_like(magnitude_spectrum)
            cv2.circle(high_freq_mask, (center_w, center_h), min(h, w) // 4, 0, -1)
            
            high_freq_content = np.sum(magnitude_spectrum * high_freq_mask) / np.sum(high_freq_mask)
            
            # Color consistency analysis
            hsv = cv2.cvtColor(face_img, cv2.COLOR_BGR2HSV)
            color_variance = np.var(hsv[:, :, 0])  # Hue variance
            
            return {
                "edge_density": float(edge_density),
                "high_freq_content": float(high_freq_content),
                "color_variance": float(color_variance),
                "artifacts_detected": edge_density > 0.1 or high_freq_content > 8.0
            }
            
        except Exception as e:
            return {
                "edge_density": 0.0,
                "high_freq_content": 0.0,
                "color_variance": 0.0,
                "artifacts_detected": False,
                "error": str(e)
            }
    
    def analyze_frame(self, frame):
        """Analyze a single frame for deepfake indicators using multiple methods."""
        try:
            faces = self.extract_faces(frame)
            
            if not faces:
                return False, 0.0, {"reason": "No faces detected"}
            
            # Analyze each detected face
            deepfake_scores = []
            analysis_details = []
            total_confidence = 0
            
            for i, face in enumerate(faces):
                face_analysis = self.comprehensive_face_analysis(face, i)
                deepfake_scores.append(face_analysis['deepfake_score'])
                analysis_details.append(face_analysis)
                total_confidence += face_analysis['confidence']
            
            # Calculate overall confidence
            avg_confidence = np.mean(deepfake_scores)
            max_confidence = np.max(deepfake_scores)
            
            # Enhanced decision making
            is_deepfake = self.make_decision(deepfake_scores, analysis_details)
            
            return is_deepfake, avg_confidence, {
                "faces_analyzed": len(faces),
                "individual_scores": deepfake_scores,
                "analysis_details": analysis_details,
                "decision_threshold": "Adaptive",
                "max_confidence": float(max_confidence),
                "confidence_variance": float(np.var(deepfake_scores))
            }
            
        except Exception as e:
            logger.error(f"Frame analysis error: {str(e)}")
            return False, 0.0, {"error": str(e)}
    
    def comprehensive_face_analysis(self, face_img, face_id):
        """Perform comprehensive analysis of a single face."""
        try:
            # CNN-based analysis
            face_rgb = cv2.cvtColor(face_img, cv2.COLOR_BGR2RGB)
            face_normalized = face_rgb.astype(np.float32) / 255.0
            face_input = np.expand_dims(face_normalized, axis=0)
            
            cnn_prediction = self.model.predict(face_input, verbose=0)[0][0]
            
            # Landmark analysis
            landmark_analysis = self.analyze_face_landmarks(face_img)
            
            # Artifact detection
            artifact_analysis = self.detect_face_swapping_artifacts(face_img)
            
            # Temporal consistency (if available)
            temporal_score = 0.5  # Placeholder for temporal analysis
            
            # Combine all scores
            combined_score = self.combine_detection_scores(
                cnn_prediction,
                landmark_analysis,
                artifact_analysis,
                temporal_score
            )
            
            return {
                "face_id": face_id,
                "cnn_confidence": float(cnn_prediction),
                "landmark_analysis": landmark_analysis,
                "artifact_analysis": artifact_analysis,
                "temporal_score": temporal_score,
                "deepfake_score": combined_score['deepfake_score'],
                "confidence": combined_score['confidence'],
                "analysis_method": "Multi-modal detection"
            }
            
        except Exception as e:
            logger.error(f"Face analysis error: {str(e)}")
            return {
                "face_id": face_id,
                "cnn_confidence": 0.5,
                "deepfake_score": 0.5,
                "confidence": 0.5,
                "error": str(e)
            }
    
    def combine_detection_scores(self, cnn_score, landmark_analysis, artifact_analysis, temporal_score):
        """Combine multiple detection scores into a final decision."""
        try:
            # Base CNN score
            combined_score = cnn_score * 0.4
            
            # Landmark-based scoring
            if landmark_analysis.get("landmark_analysis") == "Successful":
                symmetry = landmark_analysis.get("facial_symmetry", 0.5)
                ear = landmark_analysis.get("eye_aspect_ratio", 0.3)
                
                # Low symmetry or unusual EAR suggests deepfake
                if symmetry < 0.7:
                    combined_score += 0.2
                if ear < 0.2 or ear > 0.4:  # Unusual eye aspect ratio
                    combined_score += 0.1
            else:
                combined_score += 0.1  # Penalty for no landmarks
            
            # Artifact-based scoring
            if artifact_analysis.get("artifacts_detected", False):
                combined_score += 0.2
            
            edge_density = artifact_analysis.get("edge_density", 0)
            if edge_density > 0.15:  # High edge density suggests artifacts
                combined_score += 0.1
            
            # Temporal consistency
            if temporal_score < 0.3:
                combined_score += 0.1
            
            # Normalize to [0, 1]
            combined_score = min(1.0, max(0.0, combined_score))
            
            # Calculate confidence based on agreement between methods
            confidence = 0.8 if combined_score > 0.7 or combined_score < 0.3 else 0.6
            
            return {
                "deepfake_score": combined_score,
                "confidence": confidence
            }
            
        except Exception as e:
            return {
                "deepfake_score": 0.5,
                "confidence": 0.5,
                "error": str(e)
            }
    
    def make_decision(self, deepfake_scores, analysis_details):
        """Make final decision on whether video is deepfake."""
        try:
            # Adaptive threshold based on analysis quality
            avg_score = np.mean(deepfake_scores)
            max_score = np.max(deepfake_scores)
            
            # If any face has very high deepfake score, likely deepfake
            if max_score > 0.8:
                return True
            
            # If average is high and consistent across faces
            if avg_score > 0.6 and np.std(deepfake_scores) < 0.2:
                return True
            
            # Check for specific indicators
            artifact_count = sum(1 for detail in analysis_details 
                               if detail.get("artifact_analysis", {}).get("artifacts_detected", False))
            
            if artifact_count > len(analysis_details) * 0.5:  # More than 50% of faces have artifacts
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Decision making error: {str(e)}")
            return avg_score > 0.5  # Fallback to simple threshold
    
    def analyze_video(self, video_path):
        """Analyze a video file for deepfake content."""
        try:
            cap = cv2.VideoCapture(video_path)
            
            if not cap.isOpened():
                return False, 0.0, {"error": "Could not open video file"}
            
            frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            fps = cap.get(cv2.CAP_PROP_FPS)
            duration = frame_count / fps if fps > 0 else 0
            
            logger.info(f"Analyzing video: {frame_count} frames, {fps} fps, {duration:.2f}s duration")
            
            # Sample frames for analysis (every nth frame to save processing time)
            sample_rate = max(1, frame_count // 30)  # Sample up to 30 frames
            deepfake_scores = []
            frame_analyses = []
            
            frame_idx = 0
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Analyze sampled frames
                if frame_idx % sample_rate == 0:
                    is_deepfake, confidence, details = self.analyze_frame(frame)
                    deepfake_scores.append(confidence)
                    frame_analyses.append({
                        "frame_number": frame_idx,
                        "timestamp": frame_idx / fps if fps > 0 else 0,
                        "is_deepfake": is_deepfake,
                        "confidence": confidence,
                        "details": details
                    })
                
                frame_idx += 1
            
            cap.release()
            
            # Calculate overall video analysis
            if not deepfake_scores:
                return False, 0.0, {"error": "No frames could be analyzed"}
            
            avg_confidence = np.mean(deepfake_scores)
            max_confidence = np.max(deepfake_scores)
            is_deepfake = avg_confidence > 0.5 or max_confidence > 0.7
            
            analysis_summary = {
                "total_frames": frame_count,
                "analyzed_frames": len(deepfake_scores),
                "sample_rate": sample_rate,
                "video_duration": duration,
                "average_confidence": float(avg_confidence),
                "max_confidence": float(max_confidence),
                "deepfake_threshold": 0.5,
                "frame_analyses": frame_analyses[:10],  # Limit to first 10 for response size
                "analysis_timestamp": datetime.now().isoformat()
            }
            
            logger.info(f"Video analysis complete: is_deepfake={is_deepfake}, confidence={avg_confidence:.3f}")
            
            return is_deepfake, avg_confidence, analysis_summary
            
        except Exception as e:
            logger.error(f"Video analysis error: {str(e)}")
            return False, 0.0, {"error": str(e)}
    
    def generate_thumbnail(self, video_path, filename):
        """Generate a thumbnail for the video."""
        try:
            cap = cv2.VideoCapture(video_path)
            ret, frame = cap.read()
            
            if not ret:
                return None
            
            # Generate thumbnail filename
            thumbnail_filename = f"thumb_{filename.rsplit('.', 1)[0]}.jpg"
            thumbnail_path = os.path.join('uploads', 'thumbnails', thumbnail_filename)
            
            # Ensure thumbnail directory exists
            os.makedirs(os.path.dirname(thumbnail_path), exist_ok=True)
            
            # Resize frame for thumbnail
            height, width = frame.shape[:2]
            if width > 320:
                scale = 320 / width
                new_width = 320
                new_height = int(height * scale)
                frame = cv2.resize(frame, (new_width, new_height))
            
            # Save thumbnail
            cv2.imwrite(thumbnail_path, frame)
            cap.release()
            
            logger.info(f"Thumbnail generated: {thumbnail_path}")
            return thumbnail_path
            
        except Exception as e:
            logger.error(f"Thumbnail generation error: {str(e)}")
            return None
    
    def get_analysis_statistics(self):
        """Get statistics about the analysis system."""
        return {
            "model_loaded": self.model is not None,
            "face_detection_available": self.face_cascade is not None,
            "analysis_methods": ["CNN-based face analysis", "Frame sampling"],
            "supported_formats": ["MP4", "AVI", "MOV", "MKV", "WEBM"]
        }
