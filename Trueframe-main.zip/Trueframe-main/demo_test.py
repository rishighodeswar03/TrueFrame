#!/usr/bin/env python3
"""
TrueFrame Demo Test Script

This script demonstrates the key features of TrueFrame by creating
test users, uploading videos, and testing the deepfake detection.
"""

import requests
import json
import time
import os

BASE_URL = "http://localhost:5000"

def test_api_connection():
    """Test if the API is accessible."""
    try:
        response = requests.get(f"{BASE_URL}/api/stats")
        if response.status_code == 200:
            print("✓ API connection successful")
            return True
        else:
            print(f"✗ API connection failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"✗ API connection failed: {e}")
        return False

def create_test_user():
    """Create a test user account."""
    user_data = {
        "username": "testuser",
        "email": "test@example.com",
        "password": "testpassword123"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/api/register", json=user_data)
        if response.status_code == 201:
            print("✓ Test user created successfully")
            return response.json()['access_token']
        elif response.status_code == 400 and "already exists" in response.json().get('error', ''):
            print("✓ Test user already exists, logging in...")
            return login_test_user()
        else:
            print(f"✗ User creation failed: {response.json()}")
            return None
    except Exception as e:
        print(f"✗ User creation failed: {e}")
        return None

def login_test_user():
    """Login with test user credentials."""
    login_data = {
        "username": "testuser",
        "password": "testpassword123"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/api/login", json=login_data)
        if response.status_code == 200:
            print("✓ Test user login successful")
            return response.json()['access_token']
        else:
            print(f"✗ Login failed: {response.json()}")
            return None
    except Exception as e:
        print(f"✗ Login failed: {e}")
        return None

def get_stats():
    """Get platform statistics."""
    try:
        response = requests.get(f"{BASE_URL}/api/stats")
        if response.status_code == 200:
            stats = response.json()
            print(f"📊 Platform Stats:")
            print(f"   Total Videos: {stats['total_videos']}")
            print(f"   Legitimate Videos: {stats['legitimate_videos']}")
            print(f"   Deepfakes Blocked: {stats['deepfake_videos']}")
            print(f"   Total Users: {stats['total_users']}")
            print(f"   Deepfake Rate: {stats['deepfake_percentage']:.1f}%")
            return stats
        else:
            print(f"✗ Failed to get stats: {response.json()}")
            return None
    except Exception as e:
        print(f"✗ Failed to get stats: {e}")
        return None

def test_video_upload(token):
    """Test video upload functionality."""
    # Create a simple test video file (just for demonstration)
    # In a real scenario, you would upload actual video files
    print("📹 Video upload test:")
    print("   Note: This demo doesn't include actual video files.")
    print("   To test video upload, use the web interface at http://localhost:5000")
    print("   Try uploading various video files to test deepfake detection.")
    return True

def test_video_listing():
    """Test video listing functionality."""
    try:
        response = requests.get(f"{BASE_URL}/api/videos")
        if response.status_code == 200:
            data = response.json()
            videos = data.get('videos', [])
            print(f"📺 Found {len(videos)} videos on the platform")
            
            for video in videos[:3]:  # Show first 3 videos
                print(f"   - {video['filename']} by {video['uploaded_by']}")
            
            return True
        else:
            print(f"✗ Failed to get videos: {response.json()}")
            return False
    except Exception as e:
        print(f"✗ Failed to get videos: {e}")
        return False

def main():
    """Run the demo test."""
    print("🧪 TrueFrame Demo Test")
    print("=" * 50)
    
    # Test API connection
    if not test_api_connection():
        print("❌ Cannot connect to TrueFrame API. Make sure the server is running.")
        return
    
    # Create/login test user
    token = create_test_user()
    if not token:
        print("❌ Cannot authenticate. Demo cannot continue.")
        return
    
    print()
    
    # Get initial stats
    print("📊 Initial Platform Statistics:")
    get_stats()
    print()
    
    # Test video listing
    test_video_listing()
    print()
    
    # Test video upload (demo)
    test_video_upload(token)
    print()
    
    print("🎉 Demo completed successfully!")
    print()
    print("🚀 Next Steps:")
    print("   1. Open your browser and go to: http://localhost:5000")
    print("   2. Register a new account or login with 'testuser' / 'testpassword123'")
    print("   3. Try uploading different video files")
    print("   4. Test the deepfake detection system")
    print("   5. Explore the social features (like, comment)")
    print()
    print("💡 Tips:")
    print("   - The system analyzes videos frame by frame")
    print("   - Authentic videos will be accepted and displayed")
    print("   - Deepfake videos will be rejected with confidence scores")
    print("   - Check the stats page to see detection results")

if __name__ == '__main__':
    main()
