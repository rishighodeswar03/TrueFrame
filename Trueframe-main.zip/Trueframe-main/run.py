#!/usr/bin/env python3
"""
TrueFrame Application Launcher

This script provides an easy way to run the TrueFrame application
with different configurations and options.
"""

import os
import sys
from app import app, db

def create_directories():
    """Create necessary directories for the application."""
    directories = [
        'uploads',
        'uploads/videos',
        'uploads/thumbnails',
        'static/css',
        'static/js'
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"✓ Created directory: {directory}")

def init_database():
    """Initialize the database with tables."""
    try:
        with app.app_context():
            db.create_all()
            print("✓ Database initialized successfully")
    except Exception as e:
        print(f"✗ Error initializing database: {e}")
        sys.exit(1)

def check_dependencies():
    """Check if all required dependencies are installed."""
    try:
        import flask
        import tensorflow
        import cv2
        import numpy
        print("✓ All dependencies are installed")
        return True
    except ImportError as e:
        print(f"✗ Missing dependency: {e}")
        print("Please run: pip install -r requirements.txt")
        return False

def main():
    """Main application launcher."""
    print("🚀 Starting TrueFrame Application")
    print("=" * 50)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Create directories
    create_directories()
    
    # Initialize database
    init_database()
    
    # Get configuration
    config_name = os.environ.get('FLASK_ENV', 'development')
    print(f"✓ Running in {config_name} mode")
    
    # Get host and port
    host = os.environ.get('FLASK_HOST', '0.0.0.0')
    port = int(os.environ.get('FLASK_PORT', 5000))
    
    print(f"✓ Server will start on http://{host}:{port}")
    print("=" * 50)
    
    # Start the application
    try:
        app.run(
            host=host,
            port=port,
            debug=(config_name == 'development'),
            threaded=True
        )
    except KeyboardInterrupt:
        print("\n👋 TrueFrame application stopped")
    except Exception as e:
        print(f"✗ Error starting application: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
