class TrueFrameApp {
    constructor() {
        this.currentUser = null;
        this.currentVideoId = null;
        this.videosPage = 1;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.checkAuthStatus();
        this.loadStats();
        this.loadVideos();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.getAttribute('data-section');
                this.showSection(section);
            });
        });

        // Create post button
        document.getElementById('create-post-btn').addEventListener('click', () => {
            this.showSection('upload');
        });

        // Profile tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tab = e.target.getAttribute('data-tab');
                this.switchProfileTab(tab);
            });
        });

        // Refresh feed
        document.getElementById('refresh-feed').addEventListener('click', () => {
            this.loadVideos();
        });

        // Mobile menu toggle
        document.getElementById('nav-toggle').addEventListener('click', () => {
            document.getElementById('nav-menu').classList.toggle('active');
        });

        // Auth buttons
        document.getElementById('login-btn').addEventListener('click', () => this.showModal('login-modal'));
        document.getElementById('register-btn').addEventListener('click', () => this.showModal('register-modal'));
        document.getElementById('logout-btn').addEventListener('click', () => this.logout());

        // Forms
        document.getElementById('login-form').addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('register-form').addEventListener('submit', (e) => this.handleRegister(e));
        document.getElementById('comment-form').addEventListener('submit', (e) => this.handleComment(e));

        // Upload
        this.setupUpload();

        // Load more videos
        document.getElementById('load-more-videos').addEventListener('click', () => this.loadMoreVideos());

        // Modal close
        document.querySelectorAll('.modal-close').forEach(closeBtn => {
            closeBtn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                this.hideModal(modal.id);
            });
        });

        // Close modal on outside click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.hideModal(modal.id);
                }
            });
        });

        // Like button
        document.getElementById('like-btn').addEventListener('click', () => this.toggleLike());
    }

    setupUpload() {
        const uploadArea = document.getElementById('upload-area');
        const videoInput = document.getElementById('video-input');

        // Click to upload
        uploadArea.addEventListener('click', () => {
            videoInput.click();
        });

        // File input change
        videoInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                this.handleFileUpload(e.target.files[0]);
            }
        });

        // Drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0 && files[0].type.startsWith('video/')) {
                this.handleFileUpload(files[0]);
            }
        });
    }

    async handleFileUpload(file) {
        if (!this.currentUser) {
            this.showNotification('Please login to upload videos', 'error');
            return;
        }

        // Validate file size (100MB)
        if (file.size > 100 * 1024 * 1024) {
            this.showNotification('File size must be less than 100MB', 'error');
            return;
        }

        // Validate file type
        const allowedTypes = ['video/mp4', 'video/avi', 'video/mov', 'video/mkv', 'video/webm'];
        if (!allowedTypes.includes(file.type)) {
            this.showNotification('Please upload a valid video file (MP4, AVI, MOV, MKV, WEBM)', 'error');
            return;
        }

        const formData = new FormData();
        formData.append('video', file);

        this.showUploadProgress();

        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: formData
            });

            const result = await response.json();
            this.hideUploadProgress();

            if (response.ok) {
                this.showUploadResult('success', 'Video uploaded successfully! It has been analyzed and approved.');
                this.loadVideos(); // Refresh video list
                this.loadStats(); // Refresh stats
            } else {
                if (response.status === 403) {
                    this.showUploadResult('error', `Upload rejected: ${result.error}. Confidence: ${(result.confidence * 100).toFixed(1)}%`);
                } else {
                    this.showUploadResult('error', result.error || 'Upload failed');
                }
            }
        } catch (error) {
            this.hideUploadProgress();
            this.showUploadResult('error', 'Upload failed: Network error');
            console.error('Upload error:', error);
        }
    }

    showUploadProgress() {
        document.getElementById('upload-progress').style.display = 'block';
        document.getElementById('upload-result').style.display = 'none';
    }

    hideUploadProgress() {
        document.getElementById('upload-progress').style.display = 'none';
    }

    showUploadResult(type, message) {
        const resultDiv = document.getElementById('upload-result');
        resultDiv.className = `upload-result ${type}`;
        resultDiv.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
                <span>${message}</span>
            </div>
        `;
        resultDiv.style.display = 'block';
    }

    async handleLogin(e) {
        e.preventDefault();
        
        const username = document.getElementById('login-username').value;
        const password = document.getElementById('login-password').value;

        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            const result = await response.json();

            if (response.ok) {
                localStorage.setItem('token', result.access_token);
                localStorage.setItem('user', JSON.stringify(result.user));
                this.currentUser = result.user;
                this.updateAuthUI();
                this.hideModal('login-modal');
                this.showNotification('Login successful!', 'success');
                document.getElementById('login-form').reset();
            } else {
                this.showNotification(result.error || 'Login failed', 'error');
            }
        } catch (error) {
            this.showNotification('Login failed: Network error', 'error');
            console.error('Login error:', error);
        }
    }

    async handleRegister(e) {
        e.preventDefault();
        
        const username = document.getElementById('register-username').value;
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;

        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, email, password })
            });

            const result = await response.json();

            if (response.ok) {
                localStorage.setItem('token', result.access_token);
                localStorage.setItem('user', JSON.stringify(result.user));
                this.currentUser = result.user;
                this.updateAuthUI();
                this.hideModal('register-modal');
                this.showNotification('Registration successful!', 'success');
                document.getElementById('register-form').reset();
            } else {
                this.showNotification(result.error || 'Registration failed', 'error');
            }
        } catch (error) {
            this.showNotification('Registration failed: Network error', 'error');
            console.error('Registration error:', error);
        }
    }

    checkAuthStatus() {
        const token = localStorage.getItem('token');
        const user = localStorage.getItem('user');

        if (token && user) {
            this.currentUser = JSON.parse(user);
            this.updateAuthUI();
        }
    }

    updateAuthUI() {
        if (this.currentUser) {
            document.getElementById('nav-auth').style.display = 'none';
            document.getElementById('nav-user').style.display = 'flex';
            document.getElementById('profile-nav').style.display = 'flex';
            document.getElementById('create-post').style.display = 'block';
            document.getElementById('welcome-section').style.display = 'none';
            document.getElementById('username').textContent = this.currentUser.username;
            document.getElementById('profile-username').textContent = this.currentUser.username;
            document.getElementById('profile-email').textContent = this.currentUser.email;
        } else {
            document.getElementById('nav-auth').style.display = 'flex';
            document.getElementById('nav-user').style.display = 'none';
            document.getElementById('profile-nav').style.display = 'none';
            document.getElementById('create-post').style.display = 'none';
            document.getElementById('welcome-section').style.display = 'block';
        }
    }

    logout() {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        this.currentUser = null;
        this.updateAuthUI();
        this.showSection('home');
        this.showNotification('Logged out successfully', 'success');
    }

    showSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });

        // Show selected section
        document.getElementById(sectionName).classList.add('active');

        // Update nav links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');

        // Close mobile menu
        document.getElementById('nav-menu').classList.remove('active');

        // Load section-specific data
        if (sectionName === 'stats') {
            this.loadStats();
        } else if (sectionName === 'home') {
            this.loadVideos();
        } else if (sectionName === 'profile') {
            this.loadProfileData();
        }
    }

    showModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    hideModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    async loadStats() {
        try {
            const response = await fetch('/api/stats');
            const stats = await response.json();

            if (response.ok) {
                // Update hero stats
                document.getElementById('total-videos').textContent = stats.total_videos;
                document.getElementById('blocked-deepfakes').textContent = stats.deepfake_videos;
                document.getElementById('total-users').textContent = stats.total_users;

                // Update stats section
                document.getElementById('stats-total-videos').textContent = stats.total_videos;
                document.getElementById('stats-legitimate').textContent = stats.legitimate_videos;
                document.getElementById('stats-deepfakes').textContent = stats.deepfake_videos;
                document.getElementById('stats-percentage').textContent = `${stats.deepfake_percentage.toFixed(1)}%`;
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    async loadVideos() {
        try {
            const response = await fetch(`/api/videos?page=${this.videosPage}`);
            const data = await response.json();

            if (response.ok) {
                this.displayVideos(data.videos);
                this.videosPage = data.current_page + 1;
                
                // Hide load more button if no more videos
                if (data.current_page >= data.pages) {
                    document.getElementById('load-more-videos').style.display = 'none';
                }
            }
        } catch (error) {
            console.error('Error loading videos:', error);
        }
    }

    async loadMoreVideos() {
        try {
            const response = await fetch(`/api/videos?page=${this.videosPage}`);
            const data = await response.json();

            if (response.ok) {
                this.displayVideos(data.videos, true);
                this.videosPage = data.current_page + 1;
                
                // Hide load more button if no more videos
                if (data.current_page >= data.pages) {
                    document.getElementById('load-more-videos').style.display = 'none';
                }
            }
        } catch (error) {
            console.error('Error loading more videos:', error);
        }
    }

    displayVideos(videos, append = false) {
        const videoList = document.getElementById('video-list');
        
        if (!append) {
            videoList.innerHTML = '';
        }

        if (videos.length === 0 && !append) {
            videoList.innerHTML = `
                <div style="text-align: center; padding: 40px; color: #64748b;">
                    <i class="fas fa-video" style="font-size: 3rem; margin-bottom: 20px; display: block;"></i>
                    <h3>No videos yet</h3>
                    <p>Be the first to share an authentic video!</p>
                </div>
            `;
            return;
        }

        videos.forEach(video => {
            const videoCard = document.createElement('div');
            videoCard.className = 'video-card';
            videoCard.innerHTML = `
                <div class="video-thumbnail">
                    ${video.thumbnail ? 
                        `<img src="/${video.thumbnail}" alt="${video.filename}">` :
                        '<i class="fas fa-video"></i>'
                    }
                    <div class="video-play-overlay">
                        <i class="fas fa-play"></i>
                    </div>
                </div>
                <div class="video-info">
                    <div class="video-header">
                        <div class="video-author-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="video-author-info">
                            <div class="video-author-name">${video.uploaded_by}</div>
                            <div class="video-upload-time">${this.formatDate(video.created_at)}</div>
                        </div>
                    </div>
                    <div class="video-title">${video.filename}</div>
                    <div class="video-actions">
                        <div class="video-actions-left">
                            <div class="video-action" data-video-id="${video.id}">
                                <i class="far fa-heart"></i>
                                <span>${video.likes_count}</span>
                            </div>
                            <div class="video-action">
                                <i class="fas fa-comment"></i>
                                <span>${video.comments_count}</span>
                            </div>
                        </div>
                        <div class="video-share-btn">
                            <i class="fas fa-share"></i>
                        </div>
                    </div>
                </div>
            `;
            
            videoCard.addEventListener('click', (e) => {
                // Don't trigger modal if clicking on action buttons
                if (!e.target.closest('.video-action') && !e.target.closest('.video-share-btn')) {
                    this.showVideoModal(video);
                }
            });
            
            videoList.appendChild(videoCard);
        });
    }

    showVideoModal(video) {
        this.currentVideoId = video.id;
        
        document.getElementById('video-title').textContent = video.filename;
        document.getElementById('video-author').textContent = `By ${video.uploaded_by}`;
        document.getElementById('video-date').textContent = `Uploaded ${this.formatDate(video.created_at)}`;
        document.getElementById('like-count').textContent = video.likes_count;
        
        // Set video source
        const videoElement = document.getElementById('modal-video');
        videoElement.src = `/uploads/videos/${video.filename}`;
        
        // Load comments
        this.loadComments();
        
        this.showModal('video-modal');
    }

    async loadComments() {
        if (!this.currentVideoId) return;

        try {
            const response = await fetch(`/api/videos/${this.currentVideoId}/comments`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            
            const data = await response.json();
            
            if (response.ok) {
                this.displayComments(data.comments);
            }
        } catch (error) {
            console.error('Error loading comments:', error);
        }
    }

    displayComments(comments) {
        const commentsList = document.getElementById('comments-list');
        commentsList.innerHTML = '';

        if (comments.length === 0) {
            commentsList.innerHTML = '<p style="color: #64748b; text-align: center;">No comments yet. Be the first to comment!</p>';
            return;
        }

        comments.forEach(comment => {
            const commentDiv = document.createElement('div');
            commentDiv.className = 'comment';
            commentDiv.innerHTML = `
                <div class="comment-author">${comment.user}</div>
                <div class="comment-content">${comment.content}</div>
                <div class="comment-date">${this.formatDate(comment.created_at)}</div>
            `;
            commentsList.appendChild(commentDiv);
        });
    }

    async handleComment(e) {
        e.preventDefault();
        
        if (!this.currentUser) {
            this.showNotification('Please login to comment', 'error');
            return;
        }

        const content = document.getElementById('comment-input').value.trim();
        if (!content) return;

        try {
            const response = await fetch(`/api/videos/${this.currentVideoId}/comments`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({ content })
            });

            const result = await response.json();

            if (response.ok) {
                document.getElementById('comment-input').value = '';
                this.loadComments(); // Refresh comments
                this.showNotification('Comment added successfully!', 'success');
            } else {
                this.showNotification(result.error || 'Failed to add comment', 'error');
            }
        } catch (error) {
            this.showNotification('Failed to add comment: Network error', 'error');
            console.error('Comment error:', error);
        }
    }

    async toggleLike() {
        if (!this.currentUser) {
            this.showNotification('Please login to like videos', 'error');
            return;
        }

        try {
            const response = await fetch(`/api/videos/${this.currentVideoId}/like`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            const result = await response.json();

            if (response.ok) {
                const likeBtn = document.getElementById('like-btn');
                const likeCount = document.getElementById('like-count');
                
                if (result.liked) {
                    likeBtn.innerHTML = '<i class="fas fa-heart"></i><span id="like-count">' + (parseInt(likeCount.textContent) + 1) + '</span>';
                    likeBtn.classList.add('liked');
                } else {
                    likeBtn.innerHTML = '<i class="far fa-heart"></i><span id="like-count">' + (parseInt(likeCount.textContent) - 1) + '</span>';
                    likeBtn.classList.remove('liked');
                }
            }
        } catch (error) {
            console.error('Like error:', error);
        }
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now - date);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays === 1) {
            return 'Yesterday';
        } else if (diffDays < 7) {
            return `${diffDays} days ago`;
        } else {
            return date.toLocaleDateString();
        }
    }

    switchProfileTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update tab panels
        document.querySelectorAll('.tab-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        document.getElementById(`${tabName}-tab`).classList.add('active');

        // Load tab-specific data
        if (tabName === 'videos') {
            this.loadUserVideos();
        } else if (tabName === 'liked') {
            this.loadLikedVideos();
        } else if (tabName === 'activity') {
            this.loadActivityFeed();
        }
    }

    loadProfileData() {
        if (!this.currentUser) return;
        
        // Load user's videos, likes, and activity
        this.loadUserVideos();
    }

    async loadUserVideos() {
        if (!this.currentUser) return;

        try {
            const response = await fetch(`/api/videos?user_id=${this.currentUser.id}`);
            const data = await response.json();
            
            if (response.ok) {
                this.displayUserVideos(data.videos || []);
            }
        } catch (error) {
            console.error('Error loading user videos:', error);
        }
    }

    displayUserVideos(videos) {
        const userVideos = document.getElementById('user-videos');
        
        if (videos.length === 0) {
            userVideos.innerHTML = `
                <div style="text-align: center; padding: 40px; color: #64748b;">
                    <i class="fas fa-video" style="font-size: 3rem; margin-bottom: 20px; display: block;"></i>
                    <h3>No videos uploaded yet</h3>
                    <p>Share your first authentic video!</p>
                </div>
            `;
            return;
        }

        userVideos.innerHTML = videos.map(video => `
            <div class="video-card">
                <div class="video-thumbnail">
                    ${video.thumbnail ? 
                        `<img src="/${video.thumbnail}" alt="${video.filename}">` :
                        '<i class="fas fa-video"></i>'
                    }
                </div>
                <div class="video-info">
                    <div class="video-title">${video.filename}</div>
                    <div class="video-meta">
                        <span>${this.formatDate(video.created_at)}</span>
                        <span>${video.likes_count} likes</span>
                    </div>
                </div>
            </div>
        `).join('');
    }

    async loadLikedVideos() {
        // Placeholder for liked videos
        const likedVideos = document.getElementById('liked-videos');
        likedVideos.innerHTML = `
            <div style="text-align: center; padding: 40px; color: #64748b;">
                <i class="fas fa-heart" style="font-size: 3rem; margin-bottom: 20px; display: block;"></i>
                <h3>No liked videos yet</h3>
                <p>Like some videos to see them here!</p>
            </div>
        `;
    }

    async loadActivityFeed() {
        // Placeholder for activity feed
        const activityFeed = document.getElementById('activity-feed');
        activityFeed.innerHTML = `
            <div style="text-align: center; padding: 40px; color: #64748b;">
                <i class="fas fa-history" style="font-size: 3rem; margin-bottom: 20px; display: block;"></i>
                <h3>No activity yet</h3>
                <p>Your activity will appear here!</p>
            </div>
        `;
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 
                          type === 'error' ? 'fa-exclamation-circle' : 
                          type === 'warning' ? 'fa-exclamation-triangle' : 
                          'fa-info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;

        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 90px;
            right: 20px;
            background: ${type === 'success' ? '#dcfce7' : 
                        type === 'error' ? '#fee2e2' : 
                        type === 'warning' ? '#fef3c7' : 
                        '#dbeafe'};
            color: ${type === 'success' ? '#166534' : 
                    type === 'error' ? '#991b1b' : 
                    type === 'warning' ? '#92400e' : 
                    '#1e40af'};
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            z-index: 3000;
            max-width: 400px;
            animation: slideInRight 0.3s ease;
        `;

        // Add animation styles
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOutRight {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);

        document.body.appendChild(notification);

        // Remove notification after 5 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new TrueFrameApp();
});
