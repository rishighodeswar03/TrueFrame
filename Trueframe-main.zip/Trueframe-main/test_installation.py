#!/usr/bin/env python3
"""
TrueFrame Installation Test Script

This script tests if all dependencies are properly installed
and the application can start successfully.
"""

import sys
import importlib

def test_imports():
    """Test if all required modules can be imported."""
    required_modules = [
        'flask',
        'flask_cors',
        'flask_sqlalchemy',
        'flask_jwt_extended',
        'flask_migrate',
        'cv2',
        'tensorflow',
        'numpy',
        'PIL',
        'werkzeug',
        'bcrypt'
    ]
    
    print("Testing imports...")
    failed_imports = []
    
    for module in required_modules:
        try:
            importlib.import_module(module)
            print(f"✓ {module}")
        except ImportError as e:
            print(f"✗ {module}: {e}")
            failed_imports.append(module)
    
    return failed_imports

def test_app_creation():
    """Test if the Flask app can be created."""
    try:
        from app import app
        print("\n✓ Flask app created successfully")
        
        # Test database initialization
        with app.app_context():
            from models import db
            db.create_all()
            print("✓ Database tables created successfully")
        
        return True
    except Exception as e:
        print(f"\n✗ Error creating Flask app: {e}")
        return False

def test_deepfake_detector():
    """Test if the deepfake detector can be initialized."""
    try:
        from deepfake_detector import DeepfakeDetector
        detector = DeepfakeDetector()
        print("✓ Deepfake detector initialized successfully")
        
        stats = detector.get_analysis_statistics()
        print(f"✓ Detection system ready: {stats}")
        
        return True
    except Exception as e:
        print(f"✗ Error initializing deepfake detector: {e}")
        return False

def main():
    """Run all tests."""
    print("🧪 TrueFrame Installation Test")
    print("=" * 50)
    
    # Test imports
    failed_imports = test_imports()
    
    if failed_imports:
        print(f"\n❌ Installation incomplete. Missing modules: {', '.join(failed_imports)}")
        print("Please run: pip install -r requirements.txt")
        sys.exit(1)
    
    # Test app creation
    app_success = test_app_creation()
    
    # Test deepfake detector
    detector_success = test_deepfake_detector()
    
    print("\n" + "=" * 50)
    
    if app_success and detector_success:
        print("🎉 All tests passed! TrueFrame is ready to run.")
        print("\nTo start the application:")
        print("  Windows: double-click start.bat")
        print("  Linux/Mac: ./start.sh")
        print("  Or run: python run.py")
    else:
        print("❌ Some tests failed. Please check the error messages above.")
        sys.exit(1)

if __name__ == '__main__':
    main()
